<?php
include_once '../../config/koneksi.php';

class proses{

    public function __construct(){
        $db = new database();

        public function check_login($username_user, $password_user)

        $result = mysqli_query("SELECT * FROM user WHERE username_user = '$username_user' and password_user = '$password_user'");
        $user_data = mysqli_fetch_array($result);
        $no_rows = mysqli_num_rows($result);

        if($no_rows == 1){
            $_SESSION['user'] = true;
            $_SESSION['data_user'] = $user_data['user'];
            return true;

        }
        else{
            return false;
        }
    }

}

$user = new proses();
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $login = $user->check_login($_POST['username_user'], $_POST['password_user']);
    if ($login)
    {
        // Login Success
        header("location:../dasbor");
    }
    else
    {
        // Login Failed
        $msg= 'Username / password wrong';
    }
}

?>