<?php
include('../../config/koneksi.php');
include "warga.php";
$kec = new kecamatan();
// ambil dari database
$quer = "SELECT *, TIMESTAMPDIFF(YEAR, `tanggal_lahir_warga`, CURDATE()) AS usia_warga FROM warga";
$kec->setSql($quer);
$query = $kec->getSql();
$hasil = mysqli_query($db, $query);

$data_warga = array();

while ($row = mysqli_fetch_assoc($hasil)) {
  $data_warga[] = $row;
}
