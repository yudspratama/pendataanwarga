<?php
    include "../../config/kecamatan.php";
    include "../../config/koneksi.php";
    include "butuhwarga.php";
    class warga extends kecamatan implements queryWarga{
        private $query;
        
        function setQuery($query){
            $this->query = $query;
        }
        function getQuery(){
            return $this->query;
        }
    }

?>