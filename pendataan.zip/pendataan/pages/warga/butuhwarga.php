<?php
    interface queryWarga{
        public function setQuery($query);
        public function getQuery();
        
    }
?>