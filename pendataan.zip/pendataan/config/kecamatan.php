<?php
class kecamatan{
    private $sql;
    function tampil(){
        "SELECT *, TIMESTAMPDIFF(YEAR, `tanggal_lahir_warga`, CURDATE()) AS usia_warga FROM warga";
    }
    function setSql($sql){
        $this->sql = $sql;
    }
    function getSql(){
        return $this->sql;
    }
}


?>